﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Quirdor
{


    public class LogicBoard
    {
        public int Tor { get; set; } = 1;

        private Together[,] Logicboard;

        public Together player1 { get; set; }

        public Together player2 { get; set; }

        public int player1Wood { get; set; } = 10;
        public int player2Wood { get; set; } = 10;

        public Together[,] logicBoard { get { return Logicboard; } set { this.Logicboard = value; } }

        public LogicBoard()

        {
            this.logicBoard = new Together[17, 17];
            for (int i = 0; i < 17; i++)
            {
                for (int j = 0; j < 17; j++)
                {
                    this.logicBoard[i, j] = new Together(0, -999, i, j);
                    this.logicBoard[i, j].distanceFromP1 = (16 - i) + Math.Abs(8 - j);
                    this.logicBoard[i, j].distanceFromP2 = (0 + i) + Math.Abs(8 - j);
                }
            }
            this.logicBoard[0, 8].player = -1;
            this.logicBoard[16, 8].player = 1;
            player1 = this.logicBoard[16, 8];
            player2 = this.logicBoard[0, 8];


            for (int i = 0; i < 17; i++)
            {
                for (int j = 0; j < 17; j++)
                {
                    if (IsOnBoard(i + 2, j))
                        this.logicBoard[i, j].down = this.logicBoard[i + 2, j];
                    if (IsOnBoard(i - 2, j))
                        this.logicBoard[i, j].up = this.logicBoard[i - 2, j];
                    if (IsOnBoard(i, j - 2))
                        this.logicBoard[i, j].left = this.logicBoard[i, j - 2];
                    if (IsOnBoard(i, j + 2))
                        this.logicBoard[i, j].right = this.logicBoard[i, j + 2];
                }
            }
        }

        public bool IsOnBoard(int i,int j)
        {
            if (i < 0 || i > 16 || j < 0 || j > 16)
                return false;
            return true;
        }

        public bool LegalMove(int aR, int aC, int bR, int bC,LogicBoard l)
        {
            int r1 = aR * 2;
            int c1 = aC * 2;
            int r2 = bR * 2;
            int c2 = bC * 2;

            if (l.logicBoard[r2, c2].player == -999)
            {
                int verMove = r1 - r2;
                int horMove = c1 - c2;

                if (c1 == c2)
                {
                    switch (verMove)
                    {
                        case 2:
                            if (l.logicBoard[r1 - 1, c1].board == 1)
                                return false;
                            return true;
                        case -2:
                            if (l.logicBoard[r1 + 1, c1].board == 1)
                                return false;
                            return true;

                        case -4:
                            if (l.logicBoard[r1 + 1, c1].board == 1 || l.logicBoard[r1 + 3, c1].board == 1)
                                return false;
                            if (l.logicBoard[r1 + 2, c2].player != -999)
                                return true;

                            break;
                        case 4:
                            if (l.logicBoard[r1 - 1, c1].board == 1 || l.logicBoard[r1 - 3, c1].board == 1)
                                return false;
                            if (l.logicBoard[r1 - 2, c2].player != -999)
                                return true;

                            break;
                    }
                }

                if (r1 == r2)
                {
                    switch (horMove)
                    {
                        case 2:
                            if (l.logicBoard[r1, c1 - 1].board == 1)
                                return false;
                            return true;
                        case -2:
                            if (l.logicBoard[r1, c1 + 1].board == 1)
                                return false;
                            return true;
                        case -4:
                            if (l.logicBoard[r1, c2 + 1].board == 1 || l.logicBoard[r1, c2 + 3].board == 1)
                                return false;
                            if (l.logicBoard[r1, c1 + 2].player != -999)
                                return true;

                            break;
                        case 4:
                            if (l.logicBoard[r1, c1 - 1].board == 1 || l.logicBoard[r1, c1 - 3].board == 1)
                                return false;
                            if (l.logicBoard[r1, c1 - 2].player != -999)
                                return true;

                            break;
                    }
                }
            }
            return false;
        }

        public void Move(int r1, int c1, int r2, int c2, int color)
        {
            if (color == 1)
            {
                this.logicBoard[r1, c1].player = -999;
                this.logicBoard[r2, c2].player = 1;
                this.player1 = logicBoard[r2, c2];
                this.Tor *= -1;
            }
            else
            {
                this.logicBoard[r1, c1].player = -999;
                this.logicBoard[r2, c2].player = -1;
                this.player2 = logicBoard[r2, c2];
                this.Tor *= -1;
            }

        }

        //implemant greedy alghoritem each block is the distance of the way to another, use i (rows) as numbers of blocks, choose the lowest, and proced to there
        public bool IsPathPossible(LogicBoard l,int color, Queue<Together> visited, Dictionary<Together, Together> map, SearchBinaryTree toCheck, Stack<Together> shortPath)
        {
            if (toCheck.value == null)
                return false;
            Together t = SearchBinaryTree.FarLeft(toCheck).value;
            if (color == 1)
            {

                if (t.row == 0)
                {
                    ShortestPath(map, shortPath, l.player1, t);
                    return true;
                }
            }
            else
            {
                if (t.row == 16)
                {
                    ShortestPath(map, shortPath, l.player2, t);
                    return true;
                }
            }
            toCheck = SearchBinaryTree.RemoveItem(toCheck);

            if (!visited.Contains(t))
            {
                if (color == 1)
                {

                    visited.Enqueue(t);
                    if (t.up != null && LegalMove(t.row/2,t.col/2,t.up.row/2,t.up.col/2, l) && !SearchBinaryTree.SearchInTree(toCheck, t.up) && !visited.Contains(t.up))
                    {
                        map[t.up] = t;
                        SearchBinaryTree.InsertDataForPlayer1(toCheck, t.up);
                    }
                    if (t.left != null && LegalMove(t.row/2, t.col/2, t.left.row/2, t.left.col/2, l) && !SearchBinaryTree.SearchInTree(toCheck, t.left) && !visited.Contains(t.left))
                    {
                        map[t.left] = t;
                        SearchBinaryTree.InsertDataForPlayer1(toCheck, t.left);
                    }
                    if (t.right != null && LegalMove(t.row/2, t.col/2, t.right.row/2, t.right.col/2, l) && !SearchBinaryTree.SearchInTree(toCheck, t.right) && !visited.Contains(t.right))
                    {
                        map[t.right] = t;
                        SearchBinaryTree.InsertDataForPlayer1(toCheck, t.right);
                    }
                    if (t.down != null && LegalMove(t.row/2, t.col/2, t.down.row/2, t.down.col/2, l) && !SearchBinaryTree.SearchInTree(toCheck, t.down) && !visited.Contains(t.down))
                    {
                        map[t.down] = t;
                        SearchBinaryTree.InsertDataForPlayer1(toCheck, t.down);
                    }
                }
                else
                {
                    visited.Enqueue(t);
                    if (t.down != null && LegalMove(t.row/2, t.col/2, t.down.row/2, t.down.col/2, l) && !SearchBinaryTree.SearchInTree(toCheck, t.down) && !visited.Contains(t.down))
                    {
                        map[t.down] = t;
                        SearchBinaryTree.InsertDataForPlayer2(toCheck, t.down);
                    }
                    if (t.right != null && LegalMove(t.row/2, t.col/2, t.right.row/2, t.right.col/2, l) && !SearchBinaryTree.SearchInTree(toCheck, t.right) && !visited.Contains(t.right))
                    {
                        map[t.right] = t;
                        SearchBinaryTree.InsertDataForPlayer2(toCheck, t.right);
                    }
                    if (t.left != null && LegalMove(t.row/2, t.col/2, t.left.row/2, t.left.col/2, l) && !SearchBinaryTree.SearchInTree(toCheck, t.left) && !visited.Contains(t.left))
                    {
                        map[t.left] = t;
                        SearchBinaryTree.InsertDataForPlayer2(toCheck, t.left);
                    }
                    if (t.up != null && LegalMove(t.row/2, t.col/2, t.up.row/2, t.up.col/2, l) && !SearchBinaryTree.SearchInTree(toCheck, t.up) && !visited.Contains(t.up))
                    {
                        map[t.up] = t;
                        SearchBinaryTree.InsertDataForPlayer2(toCheck, t.up);
                    }
                }
            }

            return IsPathPossible(l, color, visited, map, toCheck,shortPath);
        }

        private void ShortestPath(Dictionary<Together,Together> map, Stack<Together> shortPath, Together start,Together end)
        {
            while (end.row != start.row || end.col != start.col)
            {
                shortPath.Push(end);
                end = map[end];
            }   
        }
        public bool FirstPossible(int row, int col)
        {
            if ((this.Tor == -1 && this.player2Wood > 0) || (this.Tor == 1 && this.player1Wood > 0))
            {
                bool f1 = false, f2 = false;
                AlphaBetaBoard l = new AlphaBetaBoard(this);


                l.player1 = l.logicBoard[this.player1.row, this.player1.col];
                l.player2 = l.logicBoard[this.player2.row, this.player2.col];
                if (l.logicBoard[row, col].board != 1)
                {

                    l.logicBoard[row, col].board = 1;

                    if (PictureBoxBoard.origin == null)
                    {
                        if (row % 2 != 1)
                        {
                            if (l.logicBoard[row, col].up != null && l.logicBoard[row, col].up.board != 1)
                            {
                                l.logicBoard[row, col].up.board = 1;


                                f1 = SecondPossible(l);
                                l.logicBoard[row, col].up.board = 0;
                            }
                            if (l.logicBoard[row, col].down != null && l.logicBoard[row, col].down.board != 1)
                            {
                                l.logicBoard[row, col].down.board = 1;

                                f2 = SecondPossible(l);
                            }
                        }
                        else
                        {
                            if (l.logicBoard[row, col].right != null && l.logicBoard[row, col].right.board != 1)
                            {
                                l.logicBoard[row, col].right.board = 1;


                                f1 = SecondPossible(l);
                                l.logicBoard[row, col].right.board = 0;
                            }
                            if (l.logicBoard[row, col].left != null && l.logicBoard[row, col].left.board != 1)
                            {
                                l.logicBoard[row, col].left.board = 1;

                                f2 = SecondPossible(l);
                            }
                        }
                    }
                    else
                    {
                        if (row % 2 == 1 && row == PictureBoxBoard.origin.row && (col - 2 == PictureBoxBoard.origin.col || col + 2 == PictureBoxBoard.origin.col))
                        {

                            return SecondPossible(l);
                        }
                        else if (col % 2 == 1 && col == PictureBoxBoard.origin.col && (row - 2 == PictureBoxBoard.origin.row || row + 2 == PictureBoxBoard.origin.row))
                        {

                            return SecondPossible(l);
                        }
                    }
                }
                return f1 || f2;
            }
            return false;

        }


        protected bool SecondPossible(LogicBoard l)
        {
            l.player2.player = -999;

            Queue<Together> visited = new Queue<Together>();
            Stack<Together> shortPath = new Stack<Together>();
            int color = 1;
            Dictionary<Together, Together> map = new Dictionary<Together, Together>();
            SearchBinaryTree toCheck = new SearchBinaryTree(l.player1);
            if (this.IsPathPossible(l, color, visited,map,toCheck,shortPath))
            {
                l.player2.player = -1;
                l.player1.player = -999;
                visited = new Queue<Together>();
                shortPath = new Stack<Together>();
                color = -1;
                map = new Dictionary<Together, Together>();
                toCheck = new SearchBinaryTree(l.player2);
                if (this.IsPathPossible(l, color, visited,map,toCheck,shortPath))    
                    return true;
            }
            return false;
        }

        public void PlacePlank(int row, int col)
        {
            if ((this.Tor == -1 && this.player2Wood > 0) || (this.Tor == 1 && this.player1Wood > 0))
            {
                this.logicBoard[row, col].board = 1;
                if (PictureBoxBoard.origin != null)
                {
                    if (this.Tor == -1)
                        this.player2Wood--;
                    else
                        this.player1Wood--;
                    this.Tor = Tor * -1;
                }
            }
        }

        public int WinCheck()
        {
            if (this.player1.row == 0)
                return 1;
            if (this.player2.row == 16)
                return 2;
            return 0;
        }
    }
}
