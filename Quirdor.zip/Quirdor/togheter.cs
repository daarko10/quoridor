﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quirdor
{
    public class Together
    {
        public int board { get; set; }
        public int player { get; set; }
        public int row { get; set; }
        public int col { get; set; }
        public Together left { get; set; } = null;
        public Together right { get; set; } = null;
        public Together up { get; set; } = null;
        public Together down { get; set; } = null;
        public int distanceFromP1 { get; set; }
        public int distanceFromP2 { get; set; }

        public Together(int board,  int player,int row,int col)
        {
            this.board = board;
            this.player = player;
            this.row = row;
            this.col = col;
        }

        public override string ToString()
        {
            string s = "this row: " + this.row + " and this col is: " + this.col;
            return s;
        }

    }
}
