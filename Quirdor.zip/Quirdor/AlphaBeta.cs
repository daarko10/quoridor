﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quirdor
{
    class AlphaBeta
    {
        public static Move BestMove(AlphaBetaBoard abBoard)
        {
            
            int min = int.MaxValue;
            int i = 0;
            List<AlphaBetaBoard> children = abBoard.ChildrenList(abBoard);
            AlphaBetaBoard random = new AlphaBetaBoard(new LogicBoard());
            if (!(abBoard.player2Wood == 0 && abBoard.player1Wood != 0))
            {
                abBoard.val = int.MaxValue;
                foreach (AlphaBetaBoard board in children)
                {
                    board.val = alphaBeta(board, int.MinValue, abBoard.val);
                    abBoard.val = Math.Min(abBoard.val, board.val);
                }
            }
            else
            {
                foreach (AlphaBetaBoard board in children)
                {
                    board.Heroistic();
                    
                }

            }
            foreach (AlphaBetaBoard board in children)
            {
                if(board.val < min)
                {
                    random = board;
                    min = board.val;
                }
                i++;
            }

            return random.move;




            
        }
        public static int alphaBeta(AlphaBetaBoard a, int alpha, int beta)
        {
            if (a.depth == 0)
            {
                a.Heroistic();
                return a.val;
            }

            List<AlphaBetaBoard> children = a.ChildrenList(a);
            if (a.Tor == 1)
            {
                foreach (AlphaBetaBoard board in children)
                {
                    alpha = Math.Max(alpha, alphaBeta(board, alpha, beta));
                    if (beta <= alpha)
                        break;
                }
                return alpha;
            }
            else
            {
                foreach (AlphaBetaBoard board in children)
                {
                    beta = Math.Min(beta, alphaBeta(board, alpha, beta));
                    if (beta <= alpha)
                        break; 
                }
                return beta;
            }


        }
            
        
    }
}
