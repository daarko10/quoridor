﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quirdor
{
    class AlphaBeta
    {
        public static Move BestMove(AlphaBetaBoard abBoard)
        {
            
            int min = int.MaxValue;
            int i = 0;
            List<AlphaBetaBoard> children = abBoard.ChildrenList(abBoard);
            AlphaBetaBoard random = new AlphaBetaBoard(new LogicBoard());
            if (!(abBoard.player2Wood == 0 && abBoard.player1Wood != 0))
            {
                foreach (AlphaBetaBoard board in children)
                    alphaBeta(board, int.MinValue, int.MaxValue);
            }
            foreach (AlphaBetaBoard board in children)
            {
                if(board.val < min)
                {
                    random = board;
                    min = board.val;
                }
                i++;
            }

            return random.move;




            //int i = 0;
            //int j = 0;
            //int max = int.MaxValue;
            //foreach (AlphaBetaBoard ab  in children)
            //{
            //    if(ab.val < max)
            //    {
            //        max = ab.val;
            //        j = i;
            //    }
            //    i++;
            //}

            //return children[j].move;
        }
        public static AlphaBetaBoard alphaBeta(AlphaBetaBoard a, int alpha, int beta)
        {
            if (a.depth == 0)
                return a;
            else
            {
                List<AlphaBetaBoard> children = a.ChildrenList(a);
                foreach (AlphaBetaBoard board in children)
                {
                    if(a.Tor == 1)
                    {
                        a.val = Math.Max(a.val, board.val);
                        alpha = Math.Max(alpha, a.val);
                        if (beta < alpha)
                            break;
                    }
                    else
                    {
                        a.val = Math.Min(a.val, board.val);
                        beta = Math.Min(beta, a.val);
                        if (beta < alpha)
                            break;
                    }
                }
                return a;
            }
            
        }
    }
}
