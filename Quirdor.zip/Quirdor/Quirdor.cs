﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quirdor
{

    //if all doesnt work try to make 2 different LogicBoards one for soliders and one for planks

    public partial class Quirdor : Form
    {
        public LogicBoard logicboard { get; set; }
        PictureBoxBoard[,] board;
        PictureBoxSolider[,] solidersBoard;



        public Quirdor()
        {
            this.logicboard = new LogicBoard();
            //this.logicboard.logicBoard[13, 2].board = 1;
            //this.logicboard.logicBoard[13, 4].board = 1;
            //this.logicboard.logicBoard[13, 6].board = 1;
            //this.logicboard.logicBoard[13, 8].board = 1;
            //this.logicboard.logicBoard[15, 0].board = 1;
            //this.logicboard.logicBoard[15, 2].board = 1;


            //for (int i = 0; i < 7; i = i + 2)
            //{
            //    for (int j = 1; j < 17; j = j + 2)
            //    {
            //        this.logicboard.logicBoard[i, j].board = 1;
            //    }
            //}
            //for (int i = 1; i < 8; i = i + 2)
            //{
            //    for (int j = 0; j < 16; j = j + 2)
            //    {
            //        this.logicboard.logicBoard[i, j].board = 1;
            //    }
            //}
            //for (int i = 10; i < 17; i++)
            //{
            //    for (int j = 7; j < 16; j++)
            //    {
            //        if (i % 2 == 0 && j % 2 == 1)
            //            this.logicboard.logicBoard[i, j].board = 1;
            //        if (i % 2 == 1 && j % 2 == 0)
            //            this.logicboard.logicBoard[i, j].board = 1;

            //    }
            //}

            //this.logicboard.logicBoard[3, 8].board = 0;
            //this.logicboard.logicBoard[1, 8].board = 0;
            //this.logicboard.logicBoard[5, 8].board = 0;


            //this.logicboard.player1.player = -999;
            //this.logicboard.player1 = this.logicboard.logicBoard[4, 8];
            //this.logicboard.logicBoard[4, 8].player = 1;

            //this.logicboard.player2.player = -999;
            //this.logicboard.player2 = this.logicboard.logicBoard[10, 2];
            //this.logicboard.logicBoard[10, 2].player = -1;
            DrawBoard();
            
            InitializeComponent();
            label1.Text = logicboard.Tor.ToString();
        }

        //drawing the board
        private void DrawBoard()
        {
            //making the board
            board = new PictureBoxBoard[17, 17];

            //making the solider board
            solidersBoard = new PictureBoxSolider[9, 9];


            for (int i = 0; i < 17; i++)
            {
                for (int j = 0; j < 17; j++)
                {
                    //drawing the board
                    board[i, j] = new PictureBoxBoard(i, j);
                    this.Controls.Add(board[i, j]);
                    
                    //drawing and making the soliders board + event
                    if (i % 2 == 0 && j % 2 == 0)
                    {
                        solidersBoard[i / 2, j / 2] = new PictureBoxSolider(i / 2, j / 2, logicboard.logicBoard[i, j].player);
                        this.Controls.Add(solidersBoard[i / 2, j / 2]);
                        solidersBoard[i / 2, j / 2].BringToFront();

                        solidersBoard[i / 2, j / 2].Parent = board[i, j];
                        solidersBoard[i / 2, j / 2].Location = new Point(10, 10);

                        solidersBoard[i / 2, j / 2].Click += new System.EventHandler(this.Solider_Click);
                    }
                    if (i % 2 == 1 || j % 2 == 1)
                    {
                        board[i, j].BringToFront();
                        board[i, j].Click += new System.EventHandler(this.Plank_Click);
                    }
                }
            }
            this.Refresh();
        }

        //Event for clicking a solider
        private void Solider_Click(object sender, EventArgs e)
        {
            if (PictureBoxBoard.origin == null)
            {
                PictureBoxSolider solider = (PictureBoxSolider)sender;
                int a = logicboard.logicBoard[solider.row * 2, solider.col * 2].player;
                if (PictureBoxSolider.origin != null)
                {
                    this.PlayerMove(PictureBoxSolider.origin.row,PictureBoxSolider.origin.col, solider.row, solider.col,1);
                        


                    int x = this.logicboard.WinCheck();
                    if (x == 1)
                        MessageBox.Show("Player 1 wins");
                    else if (x == 2)
                        MessageBox.Show("Player 2 wins");
                    if(logicboard.Tor == -1)
                    {
                        
                        ComputerTurn.CompMove(this);
                        if (x == 1)
                            MessageBox.Show("Player 1 wins");
                        else if (x == 2)
                            MessageBox.Show("Player 2 wins");
                    }
                    
                }
                else
                    if (a != -999 && a == logicboard.Tor)
                    PictureBoxSolider.origin = solider;
            }
            label1.Text = logicboard.player1Wood.ToString();
        }

        public bool PlayerMove(int r1,int c1,int r2, int c2, int color)
        {
            if (color == 1)
            {
                if (logicboard.LegalMove(r1, c1, r2, c2, logicboard))
                {
                    this.logicboard.Move(r1 * 2, c1 * 2, r2 * 2, c2 * 2, color);
                    solidersBoard[r1, c1].RemoveImg();
                    solidersBoard[r2, c2].PutImage(1);
                    solidersBoard[r1, c1].color = -999;
                    PictureBoxSolider.origin = null;

                    return true;
                }
            }
            else
            {
                this.logicboard.Move(r1 * 2, c1 * 2, r2 * 2, c2 * 2, color);
                solidersBoard[r1, c1].RemoveImg();
                solidersBoard[r2, c2].PutImage(-1);
                solidersBoard[r1, c1].color = -999;
                PictureBoxSolider.origin = null;

                return true;

            }
            return false;
        }


        //Event for clicking a Plank
        private void Plank_Click(object sender, EventArgs e)
        {
            
            PictureBoxBoard p = (PictureBoxBoard)sender;
            
            if (this.logicboard.FirstPossible(p.row, p.col))
                PlacePlank(p.row,p.col);
            int x = this.logicboard.WinCheck();
            if (logicboard.Tor == -1)
            {
                
                ComputerTurn.CompMove(this);
                if (x == 1)
                    MessageBox.Show("Player 1 wins");
                else if (x == 2)
                    MessageBox.Show("Player 2 wins");
            }
            label1.Text = logicboard.player1Wood.ToString();

        }


        public void PlacePlank(int row, int col)
        {
            this.logicboard.PlacePlank(row, col);
            if (row % 2 == 1)
                this.board[row,col].PutImage(4);
            else
                this.board[row, col].PutImage(3);
            if (PictureBoxBoard.origin == null)
                PictureBoxBoard.origin = this.board[row, col];
            else
                PictureBoxBoard.origin = null;

        }

    
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            logicboard = new LogicBoard();
            label1.Text = logicboard.Tor.ToString();
            for (int i = 0; i < 17; i++)
                for (int j = 0; j < 17; j++)
                    if (i % 2 == 0)
                        if (j % 2 == 0)
                        {
                            board[i, j].SendToBack();
                        }
                        else
                        {
                            board[i, j].SendToBack();
                        }
                    else if (j % 2 == 0)
                    {
                        board[i, j].SendToBack();
                    }
                        DrawBoard();
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}

