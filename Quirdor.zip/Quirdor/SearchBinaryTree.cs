﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quirdor
{
    public class SearchBinaryTree
    {
        public Together value { get; set; }
        public SearchBinaryTree rightNode { get; set; }
        public SearchBinaryTree leftNode { get; set; }


        public SearchBinaryTree(Together value)
        {
            this.value = value;
            this.rightNode = null;
            this.leftNode = null;
        }
        public SearchBinaryTree()
        {
            this.value = null;
            this.rightNode = null;
            this.leftNode = null;
        }



        static public bool SearchInTree(SearchBinaryTree node, Together data)
        {
            bool flag1 = false, flag2 = false;
            if (node.value == data)
                return true;
            if (node.rightNode != null)
                flag1 = SearchInTree(node.rightNode, data);
            if (node.leftNode != null)
                flag2 = SearchInTree(node.leftNode, data);
            return flag1 || flag2;
        }

        static public SearchBinaryTree InsertDataForPlayer1(SearchBinaryTree node, Together data)
        {
            if (node == null)
            {
                node = new SearchBinaryTree(data);
                return node;
            }
            else if (node.value == null)
            {
                node.value = data;
            }
            else if (node.value.row > data.row)
                node.leftNode = InsertDataForPlayer1(node.leftNode, data);
            else if (node.value.row <= data.row)
                node.rightNode = InsertDataForPlayer1(node.rightNode, data);
            return node;
        }

        static public SearchBinaryTree InsertDataForPlayer2(SearchBinaryTree node, Together data)
        {
            if (node == null)
            {
                node = new SearchBinaryTree(data);
                return node;
            }
            else if (node.value == null)
            {
                node.value = data;
            }
            else if (node.value.row < data.row)
                node.leftNode = InsertDataForPlayer2(node.leftNode, data);
            else if (node.value.row >= data.row)
                node.rightNode = InsertDataForPlayer2(node.rightNode, data);
            return node;
        }

        static public SearchBinaryTree FarLeft(SearchBinaryTree node)
        {
            if (node.leftNode == null)
                return node;
            return FarLeft(node.leftNode);
        }

        static public SearchBinaryTree RemoveItem(SearchBinaryTree start)
        {
            return RemoveItem(start, start, FarLeft(start));
        }
        static private SearchBinaryTree RemoveItem(SearchBinaryTree flag, SearchBinaryTree start, SearchBinaryTree node)
        {
            if (start.value == node.value)
            {
                if (start.rightNode != null)
                    start = start.rightNode;
                else
                {
                    start.value = null;
                    start.rightNode = null;
                    start.leftNode = null;
                }
                return start;
            }
            else if (start.leftNode.value == node.value)
            {
                if (start.leftNode.rightNode != null)
                    start.leftNode = start.leftNode.rightNode;
                else
                    start.leftNode = null;
                return flag;
            }

            return RemoveItem(flag, start.leftNode, node);
        } 

    }
}
