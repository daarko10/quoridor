﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Quirdor
{
    public class PictureBoxSolider : PictureBox
    {
        public int color { get; set; }
        public int row { get; set; }
        public int col { get; set; }

        static public PictureBoxSolider origin = null;

        public PictureBoxSolider(int i, int j, int color)
            :base()
        {
            
                this.color = color;
                this.row = i;
                this.col = j;

                this.BringImage(color);            
        }

        private void BringImage(int color)
        {
            string image = ImagePath.GetImage(color);
            if (image != null)
            {
                Image im = Image.FromFile(image);
                this.Image = new Bitmap(im, 50, 50);
                this.BackColor = Color.Transparent;
            }
            else
            {
                this.BackColor = Color.Transparent;
                this.Image = null;
            }
        }



        ////////////////////////////////////
        //methods


        public void RemoveImg()
        {
            this.Image = null;
        }

        public void PutImage(int colorj)
        {
            BringImage(colorj);
        }
    }
}
