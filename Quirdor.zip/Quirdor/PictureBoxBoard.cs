﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Quirdor
{
    public class PictureBoxBoard : PictureBox
    {
        public int row { get; set; }
        public int col { get; set; }


        static public PictureBoxBoard origin = null;
        public PictureBoxBoard(int i, int j)
            : base()
       {
            if (i % 2 == 0)
            {
                if (j % 2 == 0)
                {
                    int y = 150 + (34 * i), x = 500 + (34 * j);

                    this.BringImageBoard();
                    this.Location = new System.Drawing.Point(x, y);
                    this.Size = new System.Drawing.Size(70, 70);
                }
                else
                {
                    this.col = j;
                    this.row = i;
                    int y = 164 + (34 * i), x = 530 + (34 * j);

                    this.BringImagePlank(-999);
                    this.Location = new System.Drawing.Point(x, y);
                    this.Size = new System.Drawing.Size(10, 45);
                }
            }
            else
            {
                if (j % 2 == 0)
                {
                    this.col = j;
                    this.row = i;
                    int y = 180 + (34 * i), x = 510 + (34 * j);

                    this.BringImagePlank(-999);
                    this.Location = new System.Drawing.Point(x, y);
                    this.Size = new System.Drawing.Size(50, 10);
                }

                //white thingy wierd
                //if (j % 2 == 1)
                //{
                //    this.col = j;
                //    this.row = i;
                //    int y = 130 + (34 * i), x = 530 + (34 * j);

                //    this.BringImagePlank(-1);
                //    this.Location = new System.Drawing.Point(x, y);
                //    this.Size = new System.Drawing.Size(10, 45);


                //}
            }
        }

        private void BringImageBoard()
        {
            string image = ImagePath.GetImage(0);
            
                Image im = Image.FromFile(image);
                this.Image = new Bitmap(im, 70, 70);
            
        }

        private void BringImagePlank(int side)
        {
            string image = ImagePath.GetImage(side);
            if (image != null)
            {

                Image im = Image.FromFile(image);
                this.Image = null; //new Bitmap(im, 10, 100);

                this.BackColor = Color.White;


            }
            else
            {
                this.BackColor = Color.Transparent;
                this.Image = null;
            }
        }

        ////////////////////////////////////
        //methods
        public void PutImage(int side)
        {
            this.BringImagePlank(side);
        }
        public void RemoveImage()
        {
            this.Image = null;
        }
    }
}


