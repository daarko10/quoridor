﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quirdor
{
    class ImagePath
    {
        //start and end of every picture
        const string beginStr = "..\\..\\Images\\";
        const string endStr = ".png";

        //Board
        const string block = "Block";

        //players
        const string player1 = "Pion1";
        const string player2 = "Pion2";

        //Planks
        const string horPlank = "HorPlank";
        const string verPlank = "VerPlank";


        //image location
        public static string GetImage(int n)
        {
            switch (n)
            {
                case 0:
                    return beginStr + block + endStr;
                case 1:
                    return beginStr + player1 + endStr;
                case -1:
                    return beginStr + player2 + endStr;
                case 3:
                    return beginStr + horPlank + endStr;
                case 4:
                    return beginStr + verPlank + endStr;
                    
            }
            return null;
        }
    }
}
