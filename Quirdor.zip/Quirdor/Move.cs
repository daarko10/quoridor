﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quirdor
{


    class Move
    {
        public int firstRow { get; set; }
        public int firstCol { get; set; }
        public int secondRow { get; set; }
        public int secondCol { get; set; }

        public int color { get; set; } // -1 for player2, 1 for player1, 0 for plank movement

        public Move(int fR,int fC,int sR,int sC,int color)
        {
            this.firstRow = fR;
            this.firstCol = fC;
            this.secondCol = sC;
            this.secondRow = sR;

            this.color = color;
        }


    }
}
