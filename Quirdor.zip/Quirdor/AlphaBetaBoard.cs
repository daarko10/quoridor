﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quirdor
{
    class AlphaBetaBoard : LogicBoard
    {
        public int val { get; set; }
        public int depth { get; set; }
        private LogicBoard parent;
        public Move move { get; set; }

        public AlphaBetaBoard(LogicBoard b) 
            :base()
        {
            this.parent = b;
            SyncBoard(b.logicBoard);
            this.Tor = b.Tor;
            this.player1 = this.logicBoard[b.player1.row, b.player1.col];
            this.player2 = this.logicBoard[b.player2.row,b.player2.col];
            this.player1Wood = b.player1Wood;
            this.player2Wood = b.player2Wood;
            this.depth = 3;
            Heroistic();
        }

        public AlphaBetaBoard(AlphaBetaBoard b, Move m)
            :base()
        {
            this.parent = b;
            SyncBoard(b.logicBoard);
            this.player1 = this.logicBoard[b.player1.row, b.player1.col];
            this.player2 = this.logicBoard[b.player2.row, b.player2.col];
            this.player1Wood = b.player1Wood;
            this.player2Wood = b.player2Wood;
            if (m.color != 0)
                this.Move(m.firstRow, m.firstCol, m.secondRow, m.secondCol, m.color);
            else
            {
                this.PlacePlank(m.firstRow, m.firstCol);
                this.PlacePlank(m.secondRow, m.secondCol);
            }
            this.Tor = b.Tor * -1;
            this.depth = b.depth - 1;
            this.move = m;

        }

        private void SyncBoard(Together[,] board)
        {
            foreach (Together t in board)
            {
                this.logicBoard[t.row, t.col].board = board[t.row, t.col].board;
                this.logicBoard[t.row, t.col].player = board[t.row, t.col].player;
            }
        }

        public List<AlphaBetaBoard> ChildrenList(AlphaBetaBoard abBoard)
        {
            List<AlphaBetaBoard> childrenList = new List<AlphaBetaBoard>();
            Together t;
            if (abBoard.Tor == -1)
                t = this.player2;
            else
                t = this.player1;

            ////this is the solider movement.
            if (t.up != null && LegalMove(t.row / 2, t.col / 2, t.up.row / 2, t.up.col / 2, abBoard))
                childrenList.Add(new AlphaBetaBoard(this, new Move(t.row, t.col, t.up.row, t.up.col, abBoard.Tor)));

            if (t.left != null && LegalMove(t.row / 2, t.col / 2, t.left.row / 2, t.left.col / 2, abBoard))
                childrenList.Add(new AlphaBetaBoard(abBoard, new Move(t.row, t.col, t.left.row, t.left.col, abBoard.Tor)));

            if (t.right != null && LegalMove(t.row / 2, t.col / 2, t.right.row / 2, t.right.col / 2, abBoard))
                childrenList.Add(new AlphaBetaBoard(abBoard, new Move(t.row, t.col, t.right.row, t.right.col, abBoard.Tor)));

            if (t.down != null && LegalMove(t.row / 2, t.col / 2, t.down.row / 2, t.down.col / 2, abBoard))
                childrenList.Add(new AlphaBetaBoard(abBoard, new Move(t.row, t.col, t.down.row, t.down.col, abBoard.Tor)));


            //plank placement
            if ((this.player2Wood > 0 && this.Tor == -1) || (this.player1Wood > 0 && this.Tor == 1))
            {
                for (int i = 0; i < 17; i++)
                {
                    if (i % 2 == 0)
                    {
                        for (int j = 1; j < 17; j = j + 2)
                        {
                            if (abBoard.logicBoard[i, j].board == 0)
                            {
                                if (abBoard.logicBoard[i, j].down != null && abBoard.logicBoard[i, j].down.board == 0)
                                {
                                    abBoard.logicBoard[i, j].board = 1;
                                    abBoard.logicBoard[i, j].down.board = 1;
                                    if (abBoard.SecondPossible(abBoard))
                                        childrenList.Add(new AlphaBetaBoard(abBoard, new Move(i, j, i + 2, j, 0)));
                                    abBoard.logicBoard[i, j].board = 0;
                                    abBoard.logicBoard[i, j].down.board = 0;
                                }
                            }

                        }
                    }
                    else
                    {
                        for (int j = 0; j < 17; j = j + 2)
                        {
                            if (abBoard.logicBoard[i, j].board == 0)
                            {
                                if (abBoard.logicBoard[i, j].right != null && abBoard.logicBoard[i, j].right.board == 0)
                                {
                                    abBoard.logicBoard[i, j].board = 1;
                                    abBoard.logicBoard[i, j].right.board = 1;
                                    if (abBoard.SecondPossible(abBoard))
                                        childrenList.Add(new AlphaBetaBoard(abBoard, new Move(i, j, i, j + 2, 0)));
                                    abBoard.logicBoard[i, j].board = 0;
                                    abBoard.logicBoard[i, j].right.board = 0;
                                }
                            }
                        }
                    }
                }
            }

            return childrenList;
        }

        public void Heroistic()
        {
            this.player1.player = -999;
            Queue<Together> visited = new Queue<Together>();
            Stack<Together> shortPath = new Stack<Together>();
            Dictionary<Together, Together> map = new Dictionary<Together, Together>();
            SearchBinaryTree toCheck = new SearchBinaryTree(player2);
            int color = -1;
            this.IsPathPossible(this,color,visited,map,toCheck,shortPath);
            int compMove = shortPath.Count;

            this.player1.player = 1;
            this.player2.player = -999;
            visited = new Queue<Together>();
            shortPath = new Stack<Together>();
            map = new Dictionary<Together, Together>();
            toCheck = new SearchBinaryTree(player1);
            color = 1;
            this.IsPathPossible(this,color,visited,map,toCheck,shortPath);
            int PlayerMove = shortPath.Count;


            this.val = compMove - PlayerMove;


            this.player2.player = -1;
        }
    }
}
