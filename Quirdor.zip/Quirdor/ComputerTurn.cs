﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quirdor
{
    public static class ComputerTurn
    {
        public static void CompMove(Quirdor q)
        {
            AlphaBetaBoard abBoard = new AlphaBetaBoard(q.logicboard);
            Move m = AlphaBeta.BestMove(abBoard);
            if(m.color == -1)
            {
                q.PlayerMove(m.firstRow/2, m.firstCol/2, m.secondRow/2, m.secondCol/2,-1);
            }
            else
            {
                q.PlacePlank(m.firstRow,m.firstCol);
                q.PlacePlank(m.secondRow, m.secondCol);
            }
        }
    }
}
